package test;

public class test {
	public static void main(String[] args) {
		System.out.println("the answer is 42");
	}

}

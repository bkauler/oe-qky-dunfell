pref("layers.acceleration.force-enabled", true);
pref("layers.omtp.enabled", true);
